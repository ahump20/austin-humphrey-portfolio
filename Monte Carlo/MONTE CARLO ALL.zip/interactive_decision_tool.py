#!/usr/bin/env python3
"""
Blaze Intelligence Interactive Decision Tool
Real-time scenario planning and what-if analysis
"""

import json
import sys
from datetime import datetime
import numpy as np

class InteractiveDecisionTool:
    """Interactive command-line tool for strategic planning"""
    
    def __init__(self):
        self.base_params = {
            'subscriptions': 15000,
            'custom_projects': 35000,
            'data_products': 12000,
            'live_analytics': 8000,
            'partnerships': 18000,
            'training': 5000,
            'infrastructure_cost': 2500,
            'tools_cost': 1200,
            'operations_cost': 3694
        }
        
        self.scenarios = {
            '1': {
                'name': 'Conservative Growth',
                'description': 'Focus on stability and recurring revenue',
                'multipliers': {
                    'subscriptions': 1.3,
                    'data_products': 1.2,
                    'custom_projects': 0.9
                }
            },
            '2': {
                'name': 'Aggressive Expansion',
                'description': 'Maximize growth through custom projects',
                'multipliers': {
                    'custom_projects': 1.5,
                    'partnerships': 1.4,
                    'live_analytics': 1.3
                }
            },
            '3': {
                'name': 'Platform Play',
                'description': 'Build scalable SaaS products',
                'multipliers': {
                    'subscriptions': 1.5,
                    'data_products': 1.5,
                    'training': 1.2,
                    'custom_projects': 0.7
                }
            },
            '4': {
                'name': 'Partnership Focus',
                'description': 'Leverage media and team partnerships',
                'multipliers': {
                    'partnerships': 1.8,
                    'live_analytics': 1.4,
                    'subscriptions': 1.1
                }
            }
        }
    
    def display_menu(self):
        """Display main menu"""
        print("\n" + "="*60)
        print("BLAZE INTELLIGENCE - DECISION TOOL")
        print("="*60)
        print("\n1. Quick Scenario Analysis")
        print("2. Custom What-If Analysis")
        print("3. Investment ROI Calculator")
        print("4. Break-Even Analysis")
        print("5. Growth Target Calculator")
        print("6. Export Strategic Plan")
        print("0. Exit")
        print("-"*60)
        
    def scenario_analysis(self):
        """Run quick scenario analysis"""
        print("\n🎯 SCENARIO ANALYSIS")
        print("-"*40)
        print("\nSelect a scenario:")
        
        for key, scenario in self.scenarios.items():
            print(f"{key}. {scenario['name']}: {scenario['description']}")
        
        choice = input("\nEnter scenario number: ")
        
        if choice in self.scenarios:
            scenario = self.scenarios[choice]
            print(f"\n📊 Analyzing: {scenario['name']}")
            print("-"*40)
            
            # Calculate impact
            modified_revenue = 0
            original_revenue = sum(self.base_params[k] for k in 
                                  ['subscriptions', 'custom_projects', 'data_products', 
                                   'live_analytics', 'partnerships', 'training'])
            
            for stream, base_value in self.base_params.items():
                if stream in scenario['multipliers']:
                    modified_value = base_value * scenario['multipliers'][stream]
                elif stream.endswith('_cost'):
                    continue
                else:
                    modified_value = base_value
                
                if not stream.endswith('_cost'):
                    modified_revenue += modified_value
            
            total_costs = sum(v for k, v in self.base_params.items() if k.endswith('_cost'))
            
            print(f"Original Monthly Revenue: ${original_revenue:,.0f}")
            print(f"Scenario Monthly Revenue: ${modified_revenue:,.0f}")
            print(f"Revenue Change: ${modified_revenue - original_revenue:+,.0f} "
                  f"({(modified_revenue/original_revenue - 1)*100:+.1f}%)")
            print(f"\nMonthly Profit: ${modified_revenue - total_costs:,.0f}")
            print(f"Profit Margin: {(modified_revenue - total_costs)/modified_revenue*100:.1f}%")
            print(f"ROI: {(modified_revenue - total_costs)/total_costs*100:.0f}%")
            
            # 12-month projection
            growth_rate = 0.08  # 8% monthly growth
            print(f"\n📈 12-Month Projection (8% monthly growth):")
            
            for month in [3, 6, 9, 12]:
                future_revenue = modified_revenue * (1 + growth_rate) ** month
                future_profit = future_revenue - total_costs * (1 + 0.02) ** month
                print(f"  Month {month}: ${future_revenue:,.0f} revenue, "
                      f"${future_profit:,.0f} profit")
    
    def what_if_analysis(self):
        """Custom what-if analysis"""
        print("\n🔮 WHAT-IF ANALYSIS")
        print("-"*40)
        print("\nEnter new values (press Enter to keep current):")
        
        modified_params = self.base_params.copy()
        
        # Get user inputs
        for param, current in self.base_params.items():
            if not param.endswith('_cost'):
                user_input = input(f"{param.replace('_', ' ').title()} "
                                 f"[current: ${current:,}]: ")
                if user_input:
                    try:
                        modified_params[param] = float(user_input)
                    except ValueError:
                        print(f"Invalid input, keeping ${current:,}")
        
        # Calculate results
        original_revenue = sum(self.base_params[k] for k in self.base_params 
                             if not k.endswith('_cost'))
        modified_revenue = sum(modified_params[k] for k in modified_params 
                             if not k.endswith('_cost'))
        total_costs = sum(v for k, v in self.base_params.items() if k.endswith('_cost'))
        
        print("\n📊 RESULTS")
        print("-"*40)
        print(f"Modified Monthly Revenue: ${modified_revenue:,.0f}")
        print(f"Change from Base: ${modified_revenue - original_revenue:+,.0f} "
              f"({(modified_revenue/original_revenue - 1)*100:+.1f}%)")
        print(f"Monthly Profit: ${modified_revenue - total_costs:,.0f}")
        print(f"Annual Revenue: ${modified_revenue * 12:,.0f}")
        print(f"Annual Profit: ${(modified_revenue - total_costs) * 12:,.0f}")
    
    def roi_calculator(self):
        """Calculate ROI for investments"""
        print("\n💰 INVESTMENT ROI CALCULATOR")
        print("-"*40)
        
        investment = float(input("Investment amount ($): "))
        target_stream = input("Primary target (subscriptions/custom/partnerships/all): ").lower()
        
        # Estimate impact based on target
        impact_multipliers = {
            'subscriptions': 2.5,
            'custom': 3.0,
            'partnerships': 2.0,
            'all': 2.3
        }
        
        multiplier = impact_multipliers.get(target_stream, 2.3)
        
        monthly_return = investment * multiplier
        months_to_breakeven = investment / monthly_return if monthly_return > 0 else float('inf')
        annual_return = monthly_return * 12
        roi_percentage = (annual_return - investment) / investment * 100
        
        print(f"\n📈 INVESTMENT ANALYSIS")
        print("-"*40)
        print(f"Investment: ${investment:,.0f}")
        print(f"Expected Monthly Return: ${monthly_return:,.0f}")
        print(f"Months to Break Even: {months_to_breakeven:.1f}")
        print(f"Annual Return: ${annual_return:,.0f}")
        print(f"ROI: {roi_percentage:.0f}%")
        
        # Risk scenarios
        print(f"\n⚠️ RISK SCENARIOS")
        print(f"Pessimistic (50% of expected): ${monthly_return * 0.5:,.0f}/month")
        print(f"Base Case: ${monthly_return:,.0f}/month")
        print(f"Optimistic (150% of expected): ${monthly_return * 1.5:,.0f}/month")
    
    def breakeven_analysis(self):
        """Calculate break-even points"""
        print("\n📊 BREAK-EVEN ANALYSIS")
        print("-"*40)
        
        fixed_costs = sum(v for k, v in self.base_params.items() if k.endswith('_cost'))
        
        print(f"Current Fixed Costs: ${fixed_costs:,.0f}/month")
        
        # Revenue needed to break even at different margins
        margins = [0.70, 0.80, 0.90]
        
        print("\nRevenue needed to break even:")
        for margin in margins:
            revenue_needed = fixed_costs / margin
            print(f"  At {margin*100:.0f}% margin: ${revenue_needed:,.0f}/month")
        
        # Current situation
        current_revenue = sum(self.base_params[k] for k in self.base_params 
                            if not k.endswith('_cost'))
        current_margin = (current_revenue - fixed_costs) / current_revenue
        
        print(f"\nCurrent Status:")
        print(f"  Revenue: ${current_revenue:,.0f}/month")
        print(f"  Margin: {current_margin*100:.1f}%")
        print(f"  Above break-even by: ${current_revenue - fixed_costs:,.0f}/month")
    
    def growth_calculator(self):
        """Calculate required growth to hit targets"""
        print("\n🎯 GROWTH TARGET CALCULATOR")
        print("-"*40)
        
        current_revenue = sum(self.base_params[k] for k in self.base_params 
                            if not k.endswith('_cost'))
        
        target = float(input(f"Target monthly revenue (current: ${current_revenue:,}): $"))
        months = int(input("Timeframe (months): "))
        
        required_growth = (target / current_revenue) ** (1/months) - 1
        
        print(f"\n📈 GROWTH REQUIREMENTS")
        print("-"*40)
        print(f"Current: ${current_revenue:,.0f}/month")
        print(f"Target: ${target:,.0f}/month")
        print(f"Required Monthly Growth Rate: {required_growth*100:.1f}%")
        
        # Show trajectory
        print(f"\nGrowth Trajectory:")
        for month in range(1, months + 1):
            if month % 3 == 0 or month == 1 or month == months:
                projected = current_revenue * (1 + required_growth) ** month
                print(f"  Month {month}: ${projected:,.0f}")
        
        # Feasibility assessment
        print(f"\n⚖️ FEASIBILITY ASSESSMENT")
        if required_growth < 0.05:
            print("✅ Highly achievable - modest growth required")
        elif required_growth < 0.10:
            print("✅ Achievable - strong execution needed")
        elif required_growth < 0.15:
            print("⚠️ Challenging - requires aggressive expansion")
        else:
            print("⚠️ Very challenging - may need breakthrough strategy")
    
    def export_plan(self):
        """Export strategic plan"""
        print("\n📁 EXPORTING STRATEGIC PLAN")
        print("-"*40)
        
        plan = {
            'timestamp': datetime.now().isoformat(),
            'base_metrics': self.base_params,
            'current_performance': {
                'monthly_revenue': sum(self.base_params[k] for k in self.base_params 
                                     if not k.endswith('_cost')),
                'monthly_costs': sum(v for k, v in self.base_params.items() 
                                   if k.endswith('_cost')),
                'monthly_profit': sum(self.base_params[k] for k in self.base_params 
                                    if not k.endswith('_cost')) - 
                                sum(v for k, v in self.base_params.items() 
                                  if k.endswith('_cost'))
            },
            'scenarios': self.scenarios,
            'recommendations': [
                'Focus on custom analytics (highest revenue driver)',
                'Build recurring revenue through subscriptions',
                'Leverage partnerships for scale',
                'Maintain 90%+ profit margins',
                'Target $150k+ monthly revenue within 6 months'
            ]
        }
        
        filename = f'blaze_strategic_plan_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
        
        with open(f'/home/claude/{filename}', 'w') as f:
            json.dump(plan, f, indent=2)
        
        print(f"✅ Strategic plan exported to: {filename}")
        print("\nPlan includes:")
        print("  • Current performance metrics")
        print("  • Scenario definitions")
        print("  • Strategic recommendations")
        print("  • Base parameters for modeling")
    
    def run(self):
        """Main execution loop"""
        while True:
            self.display_menu()
            choice = input("\nSelect option: ")
            
            if choice == '0':
                print("\n👋 Exiting Blaze Intelligence Decision Tool")
                break
            elif choice == '1':
                self.scenario_analysis()
            elif choice == '2':
                self.what_if_analysis()
            elif choice == '3':
                self.roi_calculator()
            elif choice == '4':
                self.breakeven_analysis()
            elif choice == '5':
                self.growth_calculator()
            elif choice == '6':
                self.export_plan()
            else:
                print("Invalid option. Please try again.")
            
            input("\nPress Enter to continue...")

def main():
    """Launch interactive decision tool"""
    print("\n" + "🚀"*40)
    print("BLAZE INTELLIGENCE - INTERACTIVE DECISION TOOL")
    print("Real-time strategic planning and scenario analysis")
    print("🚀"*40)
    
    tool = InteractiveDecisionTool()
    tool.run()

if __name__ == "__main__":
    main()

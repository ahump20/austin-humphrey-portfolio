#!/bin/bash

echo "======================================"
echo "BLAZE INTELLIGENCE MONTE CARLO SYSTEM"
echo "======================================"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is required"
    exit 1
fi

# Install dependencies if needed
echo "📦 Checking dependencies..."
pip install -q -r requirements.txt 2>/dev/null || pip install -q -r requirements.txt --user

# Menu
echo ""
echo "Select option:"
echo "1. Run Advanced Monte Carlo Analysis"
echo "2. Launch Interactive Decision Tool"
echo "3. Run Both"
echo ""
read -p "Enter choice (1-3): " choice

case $choice in
    1)
        echo "🎲 Running Monte Carlo Analysis..."
        python3 monte_carlo_advanced.py
        ;;
    2)
        echo "🎮 Launching Interactive Tool..."
        python3 interactive_decision_tool.py
        ;;
    3)
        echo "🎲 Running Monte Carlo Analysis..."
        python3 monte_carlo_advanced.py
        echo ""
        read -p "Press Enter to launch Interactive Tool..."
        python3 interactive_decision_tool.py
        ;;
    *)
        echo "Invalid choice. Exiting."
        exit 1
        ;;
esac

echo ""
echo "✅ Complete! Check generated files for results."

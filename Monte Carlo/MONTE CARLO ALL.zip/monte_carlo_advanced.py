#!/usr/bin/env python3
"""
Blaze Intelligence Advanced Monte Carlo Decision Engine
Strategic optimization and scenario planning system
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats, optimize
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
import json
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Set style
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

@dataclass
class RevenueStream:
    """Enhanced revenue stream with growth dynamics"""
    name: str
    base_monthly: float
    volatility: float
    growth_rate: float = 0.05  # Monthly growth
    seasonality: Dict[int, float] = field(default_factory=dict)
    dependencies: Dict[str, float] = field(default_factory=dict)
    maturity_months: int = 12
    ceiling_multiplier: float = 3.0
    
    def generate(self, month: int, market_conditions: float, 
                 other_streams: Dict[str, float]) -> float:
        """Generate revenue with growth, seasonality, and dependencies"""
        # Base value with growth
        maturity_factor = min(1.0, month / self.maturity_months)
        growth_factor = (1 + self.growth_rate) ** month
        base = self.base_monthly * maturity_factor * growth_factor
        
        # Apply ceiling
        base = min(base, self.base_monthly * self.ceiling_multiplier)
        
        # Seasonality (month 1-12)
        season_month = (month % 12) + 1
        seasonal_factor = self.seasonality.get(season_month, 1.0)
        
        # Dependencies on other streams
        dependency_factor = 1.0
        for stream_name, weight in self.dependencies.items():
            if stream_name in other_streams:
                dependency_factor += weight * (other_streams[stream_name] / 10000)
        
        # Market conditions impact
        market_factor = 1.0 + (market_conditions - 1.0) * 0.5
        
        # Random variation
        random_factor = np.random.lognormal(0, self.volatility)
        
        return base * seasonal_factor * dependency_factor * market_factor * random_factor

@dataclass
class MarketScenario:
    """Market conditions and external factors"""
    name: str
    growth_multiplier: float
    volatility_multiplier: float
    probability: float
    triggers: List[str]
    
class AdvancedMonteCarloEngine:
    """Enhanced Monte Carlo with optimization and strategic planning"""
    
    def __init__(self):
        self.setup_revenue_streams()
        self.setup_costs()
        self.setup_market_scenarios()
        self.results_cache = {}
        
    def setup_revenue_streams(self):
        """Initialize revenue streams with enhanced parameters"""
        # Sports seasonality patterns
        baseball_season = {4: 1.2, 5: 1.3, 6: 1.4, 7: 1.5, 8: 1.4, 9: 1.3, 10: 1.2}
        football_season = {9: 1.3, 10: 1.4, 11: 1.5, 12: 1.4, 1: 1.3}
        basketball_season = {11: 1.2, 12: 1.3, 1: 1.4, 2: 1.4, 3: 1.5, 4: 1.3}
        
        self.revenue_streams = {
            'subscriptions': RevenueStream(
                'API Subscriptions', 15000, 0.15, 0.08,
                seasonality={}, dependencies={}, maturity_months=6
            ),
            'custom_projects': RevenueStream(
                'Custom Analytics', 35000, 0.30, 0.10,
                seasonality={**baseball_season, **football_season},
                dependencies={'subscriptions': 0.3}, maturity_months=3
            ),
            'data_products': RevenueStream(
                'Data Products', 12000, 0.20, 0.12,
                seasonality=baseball_season,
                dependencies={'custom_projects': 0.5}, maturity_months=9
            ),
            'live_analytics': RevenueStream(
                'Live Game Analytics', 8000, 0.35, 0.15,
                seasonality={**football_season, **basketball_season},
                dependencies={'subscriptions': 0.2, 'data_products': 0.3}
            ),
            'partnerships': RevenueStream(
                'Media Partnerships', 18000, 0.25, 0.06,
                seasonality={}, 
                dependencies={'custom_projects': 0.4, 'live_analytics': 0.3},
                maturity_months=12
            ),
            'training': RevenueStream(
                'Training & Workshops', 5000, 0.40, 0.05,
                seasonality={1: 0.8, 2: 0.9, 6: 0.8, 7: 0.7, 8: 0.8},
                dependencies={'custom_projects': 0.2}
            )
        }
        
    def setup_costs(self):
        """Initialize cost structure with scaling factors"""
        self.base_costs = {
            'infrastructure': 2500,  # Cloudflare, hosting, APIs
            'tools': 1200,           # Software, analytics platforms
            'operations': 3694        # Other operational costs
        }
        
        # Cost scaling factors based on revenue
        self.cost_scaling = {
            'infrastructure': lambda rev: 0.15 if rev > 100000 else 0.10,
            'tools': lambda rev: 0.05 if rev > 50000 else 0.03,
            'operations': lambda rev: 0.08
        }
        
    def setup_market_scenarios(self):
        """Define market scenarios"""
        self.scenarios = [
            MarketScenario(
                'Bull Market - Sports Tech Boom',
                1.4, 1.2, 0.15,
                ['Major sports betting legalization', 'AI adoption surge']
            ),
            MarketScenario(
                'Base Case - Steady Growth',
                1.0, 1.0, 0.60,
                ['Normal market conditions', 'Predictable sports calendar']
            ),
            MarketScenario(
                'Bear Market - Economic Downturn',
                0.7, 1.5, 0.20,
                ['Recession', 'Reduced sports marketing budgets']
            ),
            MarketScenario(
                'Disruption - New Competition',
                0.85, 1.3, 0.05,
                ['Major competitor entry', 'Platform commoditization']
            )
        ]
        
    def simulate_trajectory(self, months: int = 24, 
                          scenario: Optional[MarketScenario] = None) -> pd.DataFrame:
        """Simulate business trajectory over time"""
        if scenario is None:
            # Weighted random scenario selection
            probs = [s.probability for s in self.scenarios]
            scenario = np.random.choice(self.scenarios, p=probs)
        
        results = []
        stream_values = {}
        
        for month in range(1, months + 1):
            month_data = {'month': month, 'scenario': scenario.name}
            
            # Generate market conditions
            market = np.random.normal(
                scenario.growth_multiplier,
                0.1 * scenario.volatility_multiplier
            )
            market = max(0.5, min(2.0, market))  # Bound market conditions
            
            # Generate revenues
            total_revenue = 0
            for key, stream in self.revenue_streams.items():
                value = stream.generate(month, market, stream_values)
                stream_values[key] = value
                month_data[f'revenue_{key}'] = value
                total_revenue += value
            
            # Calculate costs with scaling
            total_costs = 0
            for cost_type, base in self.base_costs.items():
                scaling = self.cost_scaling[cost_type](total_revenue)
                cost = base * (1 + scaling * (total_revenue / 50000))
                month_data[f'cost_{cost_type}'] = cost
                total_costs += cost
            
            # Financial metrics
            month_data['total_revenue'] = total_revenue
            month_data['total_costs'] = total_costs
            month_data['profit'] = total_revenue - total_costs
            month_data['margin'] = month_data['profit'] / total_revenue if total_revenue > 0 else 0
            month_data['roi'] = month_data['profit'] / total_costs if total_costs > 0 else 0
            
            results.append(month_data)
        
        return pd.DataFrame(results)
    
    def optimize_resource_allocation(self, budget: float = 10000) -> Dict:
        """Optimize resource allocation for maximum expected return"""
        
        def objective(allocation):
            """Negative expected profit (for minimization)"""
            expected_profit = 0
            for i, (key, stream) in enumerate(self.revenue_streams.items()):
                # Investment impact on revenue
                investment_factor = 1 + np.log1p(allocation[i] / 1000) * 0.3
                revenue = stream.base_monthly * investment_factor
                expected_profit += revenue
            expected_profit -= allocation.sum()
            return -expected_profit
        
        # Constraints
        constraints = [
            {'type': 'eq', 'fun': lambda x: x.sum() - budget},  # Budget constraint
            {'type': 'ineq', 'fun': lambda x: x}  # Non-negative allocations
        ]
        
        # Initial guess (equal allocation)
        n_streams = len(self.revenue_streams)
        x0 = np.ones(n_streams) * budget / n_streams
        
        # Bounds
        bounds = [(0, budget * 0.5) for _ in range(n_streams)]
        
        # Optimize
        result = optimize.minimize(
            objective, x0, method='SLSQP',
            bounds=bounds, constraints=constraints
        )
        
        # Format results
        allocation_plan = {}
        for i, (key, stream) in enumerate(self.revenue_streams.items()):
            allocation_plan[stream.name] = {
                'amount': round(result.x[i], 2),
                'percentage': round(result.x[i] / budget * 100, 1),
                'expected_impact': round(
                    stream.base_monthly * (1 + np.log1p(result.x[i] / 1000) * 0.3) - 
                    stream.base_monthly, 2
                )
            }
        
        return {
            'optimal_allocation': allocation_plan,
            'expected_monthly_profit': round(-result.fun, 2),
            'roi': round((-result.fun - budget) / budget * 100, 1)
        }
    
    def sensitivity_analysis(self, n_simulations: int = 1000) -> pd.DataFrame:
        """Advanced sensitivity analysis with correlation matrix"""
        results = []
        
        for _ in range(n_simulations):
            # Vary each parameter
            trial = {}
            
            # Revenue variations
            for key, stream in self.revenue_streams.items():
                multiplier = np.random.uniform(0.5, 1.5)
                stream_copy = RevenueStream(
                    stream.name,
                    stream.base_monthly * multiplier,
                    stream.volatility,
                    stream.growth_rate
                )
                trial[f'{key}_multiplier'] = multiplier
                trial[f'{key}_revenue'] = stream_copy.generate(6, 1.0, {})
            
            # Cost variations
            for cost_type, base in self.base_costs.items():
                multiplier = np.random.uniform(0.8, 1.3)
                trial[f'{cost_type}_multiplier'] = multiplier
                trial[f'{cost_type}_cost'] = base * multiplier
            
            # Calculate profit
            total_revenue = sum(v for k, v in trial.items() if '_revenue' in k)
            total_cost = sum(v for k, v in trial.items() if '_cost' in k and 'multiplier' not in k)
            trial['profit'] = total_revenue - total_cost
            trial['margin'] = trial['profit'] / total_revenue if total_revenue > 0 else 0
            
            results.append(trial)
        
        return pd.DataFrame(results)
    
    def strategic_recommendations(self, current_state: Dict) -> Dict:
        """Generate strategic recommendations based on analysis"""
        
        # Run simulations for different strategies
        strategies = {
            'aggressive_growth': {
                'custom_projects': 1.5,
                'partnerships': 1.3,
                'live_analytics': 1.4
            },
            'stable_recurring': {
                'subscriptions': 1.6,
                'data_products': 1.4,
                'training': 1.2
            },
            'diversified': {
                stream: 1.2 for stream in self.revenue_streams.keys()
            }
        }
        
        strategy_results = {}
        
        for strategy_name, multipliers in strategies.items():
            # Apply multipliers
            original_values = {}
            for stream_key, multiplier in multipliers.items():
                if stream_key in self.revenue_streams:
                    original_values[stream_key] = self.revenue_streams[stream_key].base_monthly
                    self.revenue_streams[stream_key].base_monthly *= multiplier
            
            # Run simulation
            trajectories = [self.simulate_trajectory(12) for _ in range(100)]
            
            # Calculate metrics
            avg_profit = np.mean([t['profit'].mean() for t in trajectories])
            profit_volatility = np.std([t['profit'].std() for t in trajectories])
            growth_rate = np.mean([
                (t['profit'].iloc[-1] - t['profit'].iloc[0]) / t['profit'].iloc[0]
                for t in trajectories if t['profit'].iloc[0] > 0
            ])
            
            strategy_results[strategy_name] = {
                'expected_monthly_profit': round(avg_profit, 2),
                'profit_volatility': round(profit_volatility, 2),
                'annual_growth_rate': round(growth_rate * 100, 1),
                'risk_adjusted_return': round(avg_profit / profit_volatility if profit_volatility > 0 else 0, 2)
            }
            
            # Restore original values
            for stream_key, value in original_values.items():
                self.revenue_streams[stream_key].base_monthly = value
        
        # Identify best strategy
        best_strategy = max(
            strategy_results.items(),
            key=lambda x: x[1]['risk_adjusted_return']
        )
        
        return {
            'strategies': strategy_results,
            'recommended': best_strategy[0],
            'rationale': f"Highest risk-adjusted return of {best_strategy[1]['risk_adjusted_return']}",
            'implementation_priorities': self._get_implementation_priorities(best_strategy[0])
        }
    
    def _get_implementation_priorities(self, strategy: str) -> List[Dict]:
        """Get prioritized implementation steps"""
        priorities = {
            'aggressive_growth': [
                {
                    'priority': 1,
                    'action': 'Scale custom analytics team',
                    'timeline': '0-30 days',
                    'investment': '$5,000',
                    'expected_impact': '+$15,000/month'
                },
                {
                    'priority': 2,
                    'action': 'Launch partnership outreach',
                    'timeline': '30-60 days',
                    'investment': '$3,000',
                    'expected_impact': '+$8,000/month'
                },
                {
                    'priority': 3,
                    'action': 'Build live analytics infrastructure',
                    'timeline': '60-90 days',
                    'investment': '$7,000',
                    'expected_impact': '+$12,000/month'
                }
            ],
            'stable_recurring': [
                {
                    'priority': 1,
                    'action': 'Enhance API subscription tiers',
                    'timeline': '0-30 days',
                    'investment': '$2,000',
                    'expected_impact': '+$8,000/month'
                },
                {
                    'priority': 2,
                    'action': 'Productize successful projects',
                    'timeline': '30-60 days',
                    'investment': '$4,000',
                    'expected_impact': '+$10,000/month'
                },
                {
                    'priority': 3,
                    'action': 'Launch training program',
                    'timeline': '60-90 days',
                    'investment': '$1,500',
                    'expected_impact': '+$3,000/month'
                }
            ],
            'diversified': [
                {
                    'priority': 1,
                    'action': 'Optimize all revenue streams',
                    'timeline': '0-30 days',
                    'investment': '$3,000',
                    'expected_impact': '+$10,000/month'
                },
                {
                    'priority': 2,
                    'action': 'Improve cross-selling',
                    'timeline': '30-60 days',
                    'investment': '$2,000',
                    'expected_impact': '+$7,000/month'
                },
                {
                    'priority': 3,
                    'action': 'Build integrated platform',
                    'timeline': '60-90 days',
                    'investment': '$5,000',
                    'expected_impact': '+$12,000/month'
                }
            ]
        }
        
        return priorities.get(strategy, priorities['diversified'])
    
    def generate_executive_dashboard(self):
        """Create comprehensive executive dashboard"""
        
        # Run main simulations
        print("🎲 Running advanced Monte Carlo simulations...")
        
        trajectories = [self.simulate_trajectory(24) for _ in range(1000)]
        
        # Create figure with subplots
        fig = plt.figure(figsize=(20, 12))
        
        # 1. Revenue trajectory with confidence bands
        ax1 = plt.subplot(2, 3, 1)
        months = range(1, 25)
        
        # Calculate percentiles
        revenue_percentiles = np.percentile(
            [[t['total_revenue'].iloc[i] for t in trajectories] for i in range(24)],
            [5, 25, 50, 75, 95],
            axis=1
        ).T
        
        ax1.fill_between(months, revenue_percentiles[:, 0], revenue_percentiles[:, 4],
                        alpha=0.2, label='90% CI', color='blue')
        ax1.fill_between(months, revenue_percentiles[:, 1], revenue_percentiles[:, 3],
                        alpha=0.3, label='50% CI', color='blue')
        ax1.plot(months, revenue_percentiles[:, 2], 'b-', linewidth=2, label='Median')
        
        ax1.set_title('24-Month Revenue Projection', fontsize=14, fontweight='bold')
        ax1.set_xlabel('Month')
        ax1.set_ylabel('Monthly Revenue ($)')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Format y-axis
        ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x/1000:.0f}k'))
        
        # 2. Profit margin evolution
        ax2 = plt.subplot(2, 3, 2)
        
        margin_percentiles = np.percentile(
            [[t['margin'].iloc[i] for t in trajectories] for i in range(24)],
            [5, 25, 50, 75, 95],
            axis=1
        ).T
        
        ax2.fill_between(months, margin_percentiles[:, 0], margin_percentiles[:, 4],
                        alpha=0.2, color='green')
        ax2.plot(months, margin_percentiles[:, 2], 'g-', linewidth=2)
        ax2.axhline(y=0.9, color='red', linestyle='--', alpha=0.5, label='Target: 90%')
        
        ax2.set_title('Profit Margin Evolution', fontsize=14, fontweight='bold')
        ax2.set_xlabel('Month')
        ax2.set_ylabel('Profit Margin')
        ax2.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{x*100:.0f}%'))
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # 3. Revenue stream composition (Month 12)
        ax3 = plt.subplot(2, 3, 3)
        
        month_12_revenues = {}
        for stream_key in self.revenue_streams.keys():
            values = [t[f'revenue_{stream_key}'].iloc[11] for t in trajectories]
            month_12_revenues[self.revenue_streams[stream_key].name] = np.mean(values)
        
        colors = plt.cm.Set3(range(len(month_12_revenues)))
        wedges, texts, autotexts = ax3.pie(
            month_12_revenues.values(),
            labels=month_12_revenues.keys(),
            autopct='%1.1f%%',
            colors=colors,
            startangle=90
        )
        
        ax3.set_title('Revenue Mix (Month 12)', fontsize=14, fontweight='bold')
        
        # 4. Scenario impact analysis
        ax4 = plt.subplot(2, 3, 4)
        
        scenario_profits = {}
        for scenario in self.scenarios:
            scenario_trajectories = [
                self.simulate_trajectory(12, scenario) for _ in range(100)
            ]
            profits = [t['profit'].mean() for t in scenario_trajectories]
            scenario_profits[scenario.name] = profits
        
        positions = range(len(self.scenarios))
        bp = ax4.boxplot(
            [scenario_profits[s.name] for s in self.scenarios],
            positions=positions,
            widths=0.6,
            patch_artist=True
        )
        
        for patch, color in zip(bp['boxes'], plt.cm.Pastel1(range(len(self.scenarios)))):
            patch.set_facecolor(color)
        
        ax4.set_xticklabels([s.name.split(' - ')[0] for s in self.scenarios], rotation=45)
        ax4.set_title('Scenario Impact on Profitability', fontsize=14, fontweight='bold')
        ax4.set_ylabel('Monthly Profit ($)')
        ax4.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x/1000:.0f}k'))
        ax4.grid(True, alpha=0.3, axis='y')
        
        # 5. Sensitivity tornado chart
        ax5 = plt.subplot(2, 3, 5)
        
        sensitivity_df = self.sensitivity_analysis(500)
        
        # Calculate correlations with profit
        correlations = {}
        for col in sensitivity_df.columns:
            if 'multiplier' in col:
                corr = sensitivity_df[col].corr(sensitivity_df['profit'])
                name = col.replace('_multiplier', '').replace('_', ' ').title()
                correlations[name] = corr
        
        # Sort by absolute correlation
        sorted_corr = sorted(correlations.items(), key=lambda x: abs(x[1]), reverse=True)[:8]
        
        names = [x[0] for x in sorted_corr]
        values = [x[1] for x in sorted_corr]
        colors = ['green' if v > 0 else 'red' for v in values]
        
        y_pos = range(len(names))
        ax5.barh(y_pos, values, color=colors, alpha=0.7)
        ax5.set_yticks(y_pos)
        ax5.set_yticklabels(names)
        ax5.set_xlabel('Correlation with Profit')
        ax5.set_title('Sensitivity Analysis', fontsize=14, fontweight='bold')
        ax5.axvline(x=0, color='black', linewidth=0.5)
        ax5.grid(True, alpha=0.3, axis='x')
        
        # 6. Growth trajectory comparison
        ax6 = plt.subplot(2, 3, 6)
        
        # Compare different growth strategies
        strategies = {
            'Conservative': 0.03,
            'Base Case': 0.08,
            'Aggressive': 0.15
        }
        
        for name, rate in strategies.items():
            # Temporarily modify growth rates
            original_rates = {}
            for key, stream in self.revenue_streams.items():
                original_rates[key] = stream.growth_rate
                stream.growth_rate = rate
            
            # Simulate
            traj = self.simulate_trajectory(24)
            ax6.plot(months, traj['total_revenue'], label=f'{name} ({rate*100:.0f}%/mo)', linewidth=2)
            
            # Restore rates
            for key, orig_rate in original_rates.items():
                self.revenue_streams[key].growth_rate = orig_rate
        
        ax6.set_title('Growth Strategy Comparison', fontsize=14, fontweight='bold')
        ax6.set_xlabel('Month')
        ax6.set_ylabel('Monthly Revenue ($)')
        ax6.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x/1000:.0f}k'))
        ax6.legend()
        ax6.grid(True, alpha=0.3)
        
        plt.suptitle('Blaze Intelligence - Advanced Monte Carlo Analysis', 
                    fontsize=16, fontweight='bold', y=0.98)
        plt.tight_layout()
        
        # Save dashboard
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        dashboard_path = f'/home/claude/blaze_executive_dashboard_{timestamp}.png'
        plt.savefig(dashboard_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        print(f"📊 Executive dashboard saved: {dashboard_path}")
        
        # Calculate summary statistics
        final_months = [t['total_revenue'].iloc[-1] for t in trajectories]
        total_profits = [t['profit'].sum() for t in trajectories]
        
        return {
            'dashboard_path': dashboard_path,
            'key_metrics': {
                'expected_24mo_revenue': round(np.mean(final_months), 2),
                'median_24mo_revenue': round(np.median(final_months), 2),
                'total_profit_24mo': round(np.mean(total_profits), 2),
                'probability_150k_month': round(sum(1 for x in final_months if x > 150000) / len(final_months), 3),
                'probability_200k_month': round(sum(1 for x in final_months if x > 200000) / len(final_months), 3)
            }
        }

def main():
    """Execute advanced Monte Carlo analysis"""
    print("\n" + "="*80)
    print("BLAZE INTELLIGENCE - ADVANCED MONTE CARLO DECISION ENGINE")
    print("="*80)
    
    engine = AdvancedMonteCarloEngine()
    
    # 1. Generate executive dashboard
    dashboard = engine.generate_executive_dashboard()
    
    print("\n📈 24-MONTH PROJECTIONS")
    print("-"*40)
    for key, value in dashboard['key_metrics'].items():
        if 'probability' in key:
            print(f"{key.replace('_', ' ').title()}: {value*100:.1f}%")
        else:
            print(f"{key.replace('_', ' ').title()}: ${value:,.0f}")
    
    # 2. Optimize resource allocation
    print("\n💡 OPTIMAL RESOURCE ALLOCATION ($10,000 budget)")
    print("-"*40)
    allocation = engine.optimize_resource_allocation(10000)
    
    for stream, details in allocation['optimal_allocation'].items():
        print(f"{stream}: ${details['amount']:,.0f} ({details['percentage']}%)")
        print(f"  → Expected impact: +${details['expected_impact']:,.0f}/month")
    
    print(f"\nTotal Expected Monthly Profit: ${allocation['expected_monthly_profit']:,.0f}")
    print(f"ROI: {allocation['roi']}%")
    
    # 3. Strategic recommendations
    print("\n🎯 STRATEGIC RECOMMENDATIONS")
    print("-"*40)
    
    current_state = {
        'monthly_revenue': 86096,
        'growth_rate': 0.08,
        'primary_stream': 'custom_projects'
    }
    
    recommendations = engine.strategic_recommendations(current_state)
    
    print("\nStrategy Analysis:")
    for strategy, metrics in recommendations['strategies'].items():
        print(f"\n{strategy.replace('_', ' ').title()}:")
        print(f"  Expected Profit: ${metrics['expected_monthly_profit']:,.0f}")
        print(f"  Volatility: ${metrics['profit_volatility']:,.0f}")
        print(f"  Growth Rate: {metrics['annual_growth_rate']}%")
        print(f"  Risk-Adjusted Return: {metrics['risk_adjusted_return']}")
    
    print(f"\n✅ RECOMMENDED STRATEGY: {recommendations['recommended'].replace('_', ' ').title()}")
    print(f"Rationale: {recommendations['rationale']}")
    
    print("\n📋 IMPLEMENTATION PRIORITIES:")
    for priority in recommendations['implementation_priorities']:
        print(f"\n{priority['priority']}. {priority['action']}")
        print(f"   Timeline: {priority['timeline']}")
        print(f"   Investment: {priority['investment']}")
        print(f"   Impact: {priority['expected_impact']}")
    
    # 4. Risk analysis
    print("\n⚠️ RISK ASSESSMENT")
    print("-"*40)
    
    # Calculate downside risks
    trajectories = [engine.simulate_trajectory(12) for _ in range(1000)]
    profits = [t['profit'].mean() for t in trajectories]
    
    var_95 = np.percentile(profits, 5)
    cvar_95 = np.mean([p for p in profits if p <= var_95])
    
    print(f"Value at Risk (95% confidence): ${var_95:,.0f}/month")
    print(f"Conditional VaR (expected loss if threshold breached): ${cvar_95:,.0f}/month")
    print(f"Probability of loss: {sum(1 for p in profits if p < 0) / len(profits) * 100:.2f}%")
    
    # Save comprehensive report
    report_path = '/home/claude/blaze_advanced_analysis.json'
    
    report = {
        'timestamp': datetime.now().isoformat(),
        'dashboard': dashboard['dashboard_path'],
        'key_metrics': dashboard['key_metrics'],
        'optimization': allocation,
        'strategies': recommendations,
        'risk_metrics': {
            'var_95': round(var_95, 2),
            'cvar_95': round(cvar_95, 2),
            'probability_of_loss': round(sum(1 for p in profits if p < 0) / len(profits), 4)
        }
    }
    
    with open(report_path, 'w') as f:
        json.dump(report, f, indent=2)
    
    print(f"\n📁 Full report saved: {report_path}")
    print("\n" + "="*80)
    print("ANALYSIS COMPLETE - Ready for strategic decision making")
    print("="*80)

if __name__ == "__main__":
    main()
